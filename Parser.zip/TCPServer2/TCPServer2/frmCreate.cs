﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net.Sockets;

namespace TCPServer2
{
    public partial class frmCreate : Form
    {
        public frmCreate()
        {
            InitializeComponent();
            this.Text = "Send Message To " + Form1.selid;
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnSend_Click(object sender, EventArgs e)
        {
            if (textBox1.Text != "")
            {
                Socket handler2 = null;
                AsynchronousSocketListener.sernumdict2.TryGetValue(Form1.selid, out handler2);
                if (handler2 == null)
                {
                    MessageBox.Show("Message could not be sent");
                }
                AsynchronousSocketListener.Send(handler2, textBox1.Text + "\r\n");
            }

            else
            {
                MessageBox.Show("Please enter a message to be sent");
            }

        }
    }
}
